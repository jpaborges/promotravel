$(document).ready(function () {
//							$('img').animate({width:'154px'});
							$('input[type=button]').click(
											 function(){
												 $('.treta').transition({ scale: 1.5});
												 }
											 );
							});	
